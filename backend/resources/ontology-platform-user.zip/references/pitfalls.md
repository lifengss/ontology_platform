# 坑点与规避（按场景）

## 连接 / 鉴权
- **localhost 挂起**：Windows 把 `localhost` 解析成 IPv6 `::1`，后端绑 `0.0.0.0`（IPv4）→ 请求卡死。脚本一律用 `http://127.0.0.1:8000`。
- **token 过期**：后端重启/长时间后 token 失效（接口返回 `401 UNAUTHORIZED` 或取到 0 条）。重新 `POST /api/auth/login?mode=bearer` 刷新 `.op_token.txt`。重启后端后 token 会失效，需重新登录。

## 实例导入
- **CSV 空值 `""`**：`/api/ingest/upload` 经 csv.DictReader 把空字段读成空串，`_coerce_record_types` 仅 continue 不删字段 → SHACL 枚举/必填报 `Value Literal("") not in list`。**改用 `POST /api/ingest/preview`（body 为 IngestPreviewRequest，records 为 dict 列表，空字段直接省略）** 即可 0 违规。
- **object_type / field_map 传参**：都放 **body**（放 query 会被忽略并默认某对象；field_map 空会被忽略）。identity map `{k:k}` 也可。
- **分页参数**：`page`/`pageSize`（上限 200）；用错 `page_size/offset` 会固定只回 50 条。
- **大批量**：单对象单 JSONL，曾"整读改写 + os.replace"，Windows 下 `os.replace` 间歇 `WinError 5`；approve 逐行全表扫描 O(n²)。规避：小批次（200~500/批）+ 超时 600 + 按库内 key 去重 + 断点续传（**仅记录真正成功 key**；无条件写 key 会在失败批次污染去重导致"全部已导入"误判）。修复后（追加写 + 稳定键索引）可分钟级万行。
- **断点续传污染**：脚本在批次失败时若仍把该批 key 写入断点文件，后续去重会跳过未导入的行 → 只在 `import>0` 时写 key，并清空被污染的断点文件后重试。
- **原因不明地拿不到全量**：先看后端日志 `JSONL 解析跳过` 告警（文件有并发写撕裂残行），再核对 API `total` 与源对象文件行数是否一致。

## 实例修改
- **PUT 清空**：`PUT /api/ingest/instances/{id}` 只传单字段会把其余属性清空 → 必须 `{"instance":{完整字段}}`。字段级修改用 PATCH。
- **PATCH 删键**：不支持删键（HF-10）；物理删除需本体 v4 breaking。

## 能力 / opl-expr
- **按 cap_id 执行**：`execute` 按**能力 id**，按 name 会 NOT_FOUND。
- **inputs 覆盖语义**：`execute` 的 `inputs` 是"覆盖 + 缺失回落实例值"，不是整体替换（需显式传 `attr_bom_set='NONE'` 等以避免沿用模板实例值）。
- **binds 无条件预求值**：`binds` 变量即使用不到也先算，键缺失即 `MISSING_INPUT_ATTR`；可选属性内联进 `if()` 参数。
- **final 位置多行嵌套 if**：易报"最后一个表达式之后不应再有内容" → 先 bind 变量，final 只放单层选择。

## 问数 / 溯源
- **LLM 需配好**：`nl-query` 依赖设置里配好的 LLM（llm_config.json + 进程 env `LLM_API_KEY`），否则退回 fallback 或无结果。
- **拒答而非编数**：lookup 0 命中 / `data_gaps` 非空 → 转成"查不到 + 缺什么"，绝不编数字（"——"不参与运算）。

## 浏览器自动化
- 系统 Chrome：`--headless=new --no-sandbox --disable-gpu --remote-debugging-port=9222 --user-data-dir=<tmp>`，再 `agent-browser connect 9222`。**勿用 npm shim**（bash 下路径被弄成 D:/c/）。截图路径用 D 盘绝对路径（写 C 盘报 os error 3）。

## 打印 / PDF
- Chrome `--headless=new --print-to-pdf` 可能静默产不出文件（exit 0 无输出）→ 用 `--headless`（不带 new）+ 全新 profile；`>/dev/null` 会掩盖失败，务必核对输出文件时间/大小。

## 后端重启
- `python backend/main.py`（无 --reload）；重启后 token 失效需重登录；MCP 端点会重挂载（先 `POST /api/mcp/server/publish`）。
