# 数据模型与语义速查

## 核心数据模型（业务层）
- **本体 Ontology**
  - `name`(必填)、`modeling_type`、`version`、`objects[]`、`constraints[]`、`status`（`draft` → `active`）。
  - `active` 才写入 Jena 并被 MCP/图谱消费；`draft` 仅建模页可见。
- **对象类型 OntologyObject**
  - `id`、`name`、`business_definition`(必填 ≥5 字符)、`stable_key`(业务主键，必填，指向本对象某属性 id)、`attributes[]`、`relations[]`。
- **属性 ObjectAttribute**
  - `id`、`name`、`data_type`(默认 string)、`required`、`constraints{min_length,max_length,pattern,minimum,maximum,enum}`。
- **关系 ObjectRelation**
  - `id`、`name`、`target_object`(必填)、`cardinality`(默认 many_to_one)、`inverse_name`。

## 枚举取值的唯一权威
| 字段 | 取值 |
|---|---|
| data_type | `string` / `integer` / `float` / `boolean` / `date` / `datetime` |
| cardinality | `one_to_one` / `one_to_many` / `many_to_one` / `many_to_many` |
| modeling_type | `manual` / `reverse` / `schema` / `hybrid` |

> 注意：产品线分组等 enum 可能是**全角括号**（如 `服务器（SV、AI、边缘）`），枚举值必须与源表完全一致才能命中。

## 稳定键（stable_key）
- 指向本对象某个属性；用于实例去重/合并。组合键要唯一且在源表可验证（如 `批次|区域|机型|条款|客户`，唯一 122500/122500，max 33 字符 < 64 上限）。
- 属性 `attr_baseline_code` 等常有 pattern `^[A-Za-z0-9_\-]+$`（仅 ASCII），编码含中文/斜杠会**整批 0 条** → 用 ASCII 国家码（CN/US/HK…）+ 分组 ASCII 码（SRV/STR/HPC）生成，如 `PD-CN-SVC-SRV`。

## 四层语义（L1-L4）
- **L1 语义层**：对象/属性/约束/字典 —— 口径唯一来源，版本化；口径变更只改这里。
- **L2 能力层**：20 个公式能力，MCP 发布，禁止脚本；`lookup` 只读语义层，`ref` 只读上游能力，无脚本、无 IO、结果可复现。
- **L3 业务层**：反解/背包/归因，只做"枚举与求解"，数值必须回平台算。
- **L4 交互层**：WorkBuddy / NLQ，只负责措辞，不产出数字。

## 能力链（以成本评价为例，等价可替换）
`D 服务率 → E 人工 / K 备件辅助 / N 管理 / F 备件直接(行级聚合) → O 成本合计 → S 维保占比`。
- `lookup()` 取基线实例（按维度键）；`ref()` 组引用链（上游能力）。
- 预计算固定值属性（supplier / baseline 等）语义=**对照值**，计算链不消费（除个别兜底值）；如需物理删除需本体 v4 breaking（HF-10：PATCH 不支持删键）。

## 多项目隔离
- 所有 API 走 `?project_id=`；MCP 端点按项目 `/mcp/{project_id}`；同一项目多本体共享端点。
