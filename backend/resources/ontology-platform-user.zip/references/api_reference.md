# 关键 REST / MCP 端点参考

> 约定：`BASE = http://127.0.0.1:8000`（勿用 localhost）。所有 `/api/*` 需 `Authorization: Bearer <token>`。`get()` 返回 `(status, dict)` 元组，勿直接 `.json()`。

## 鉴权
- 登录：`POST /api/auth/login?mode=bearer`，body `{"username":"admin","password":"<pwd>"}` → 响应 `data.token`。初始密码在 `backend/secrets/bootstrap_admin.txt` 或 `ONTOLOGY_BOOTSTRAP_ADMIN_PASSWORD`。
- 本机回归可 `ONTOLOGY_AUTH_ENABLED=false` 关闭鉴权（此时 `/api/health` 返回 200 而非 401）。

## 建模
- 本体 CRUD：`/api/ontologies`、`/api/ontologies/{oid}`（GET 单本体会随带 objects/constraints）。
- 发布 active：`POST /api/ontologies/{oid}/publish?project_id=<pid>`（或对应 status 变更端点）。

## 实例导入
- 预览（推荐，空字段省略）：`POST /api/ingest/preview?project_id=<pid>`
  ```json
  {"ontology_id":"<oid>","object_type":"<obj>","source":{"kind":"field_map","records":[{"attr_x":"v","attr_y":1}]},"mapping":{"field_map":{"attr_x":"attr_x"}}}
  ```
- 审批：`POST /api/ingest/candidates/{candidate_id}/approve?project_id=<pid>`。
- 列表：`GET /api/ingest/instances?project_id=<pid>&ontology_id=<oid>&object_type=<obj>&page=1&pageSize=200`（`page`/`pageSize`，上限 200）。

## 实例修改
- 整对象替换（危险，会清空其余字段）：`PUT /api/ingest/instances/{id}` body `{"instance":{完整字段}}`。
- 字段级：`PATCH /api/ingest/instances/{id}`（不支持删键）。

## 能力
- 清单：`GET /api/capabilities?project_id=<pid>&ontology_id=<oid>&pageSize=50` → `data.items[]`（含 name/version/status）。
- 执行：`POST /api/capabilities/{cap_id}/execute` body `{"instance_id":"<实例id>","inputs":{...},"dry_run":true}`。**按能力 id**（按 name 会 NOT_FOUND）。`dry_run=true` 不写回。
- 校验：`POST /api/capabilities/{cap_id}/validate?draft_expression=<urlencoded>`（无 `/api/capabilities/validate`）。

## 问数 / 图谱
- 自然语言：`POST /api/graph/{ontology_id}/nl-query?project_id=<pid>` body `{"query":"..."}`。
- MCP 工具（`/mcp/<project_id>`，streamable-http）：`ontology_query` / `instance_get` / `inference_trace` / `action_invoke` / `term_lookup` / `capability_call`。
- MCP 令牌：`POST /api/mcp/server/token?project_id=<pid>` → `data.token`（不走 REST Bearer，用项目静态 token）。
- 平台能力清单：`capability_call(capability="")` → `{count, capabilities[]}`。

## 健康 / 配置
- `GET /api/health`（在线 401；关鉴权 200）。
- `GET /mcp/{project_id}` 无 session 头返回 405 提示（Streamable HTTP GET 需带 `Mcp-Session-Id`）。

## 补充
- 校验/推理/动作等走对应 `router_*`；能力执行返回"值 + 溯源四要素"（能力版本 + inputs + lookup 命中 + 计算值）。
