---
name: ontology-platform-user
description: 在「格物 lattice · 企业业务本体平台」上做建模、实例批量导入/修改、智能问数、能力调用溯源的用户侧操作指南。当用户要为本体平台新建/修改本体对象与属性、批量导入或修改实例、跑自然语言问数（含反解/预算/归因）、执行公式能力并查看溯源（lookup 命中、ref 链、四要素 trace）时使用本 skill。沉淀了平台 API 用法、数据模型与 Windows/大数据量坑点，目标是让用户侧更易用、更友好。当任务涉及成本核算模型、服务产品成本、维保成本等语义底座场景，也应优先考虑此 skill。
agent_created: true
---

# 格物 · 企业业务本体平台 —— 用户侧操作指南

## 目标与定位
本 skill 面向「格物 lattice · 企业业务本体平台」的**用户侧**：大模型 Agent 的语义底座，约束数据使用逻辑、降低幻觉。它不做业务系统、不允许写脚本 —— 一切计算以"可解释表达式 + 可回指 lookup"完成。用户工作的核心是：**建模（定义对象/属性/关系）→ 灌实例 → 对外发布 → 问数/能力调用 → 溯源**。

平台有 8 功能页：建模 / 实例导入 / 图谱 / 推理 / 业务动作 / MCP / 日志 / 设置。所有 API 走 `?project_id=`；MCP 端点按项目 `/mcp/{project_id}`，同一项目多本体共享端点。

## 四层语义（先定界再动手）
- **L1 语义层**：对象/属性/约束/字典 —— 口径唯一来源。
- **L2 能力层**：20 个公式能力，MCP 发布，禁止脚本。
- **L3 业务层**：反解/背包/归因，只做"枚举与求解"，**数值必须回平台算**。
- **L4 交互层**：WorkBuddy / NLQ，只组织措辞，不产出数字。

## 何时用哪种能力（快速判断）
| 需求 | 用 |
|---|---|
| 定义"有什么、怎么唯一识别" | 本体建模（对象/属性/关系/约束/稳定键） |
| 灌数据 | 实例导入（preview → 候选 → approve） |
| 改一条/一批数据 | PATCH（字段级）/ PUT（整对象替换，需完整 payload） |
| 问数 | `POST /api/graph/{ontology_id}/nl-query` 或 MCP 工具 |
| 算一条成本/数值并溯源 | `POST /api/capabilities/{cap_id}/execute`（dry_run，REST 内部通道） |
| **从 agent 平台验证/调用能力** | **MCP `capability_call`**（`/mcp/{pid}`，`execution_channel=mcp`）——对外验收优先走这个 |
| 看某能力是否可用/版本 | `capability_call(capability="")` / `GET /api/capabilities` |

## 前置与连接（必读）
- **鉴权**：`/api/*` 默认需 `Authorization: Bearer <token>`；`POST /api/auth/login?mode=bearer` 取 `data.token`（初始管理员 admin，密码在 `backend/secrets/bootstrap_admin.txt` 或环境变量 `ONTOLOGY_BOOTSTRAP_ADMIN_PASSWORD`）。本地回归可设 `ONTOLOGY_AUTH_ENABLED=false` 关鉴权。
- **连接地址**：一律用 **`http://127.0.0.1:8000`**，不要用 `localhost`（Windows 会解析到 IPv6 `::1` 导致请求挂起）。
- **项目/本体**：所有查询带 `project_id`；本体用 `ontology_id`。多项目隔离。
- **MCP 令牌**：`POST /api/mcp/server/token?project_id=<pid>`（不走 REST Bearer，用项目静态 token）。
- **发布 MCP Server（对外 / agent 平台消费）**：`POST /api/mcp/server/publish?project_id=<pid>&ontology_id=<oid>`，发布后端点 `/mcp/{pid}` 才暴露（tools/list、tools/call、capability_call/instance_get/ontology_query 等）。**初调可能返回 503「MCP 端点启动中，请稍后重试」，需轮询重试（每 2s，通常 1~3 次即成功）**。仅 REST 内部建模/校验/问数**不需要**发布 MCP；但**对外/agent 验收必须发布**。
- **测试/验证应从 agent 平台走 MCP**：对外验收是 `MCPClient.initialize()`（`/mcp/{pid}`，带 `Authorization: Bearer <项目token>`，取 `Mcp-Session-Id` 回传）→ `tools/list` 确认能力/工具 → `tools/call` `capability_call`。执行返回 `status`/`value`/`trace`（lookup 命中 + ref 链），`execution_channel=mcp` 可证明确走 agent 通道。
- **后端改动需重启**：`python backend/main.py`（无 --reload）；CORS 允许 localhost 任意端口。

## 建模（L1）
1. **数据模型**：本体 Ontology(name/modeling_type/version/objects/constraints/status，`draft`→`active`)；对象 OntologyObject(id/name/business_definition≥5字符/stable_key 指向本对象某属性/attributes/relations)；属性 ObjectAttribute(id/name/data_type/required/constraints{min_length,max_length,pattern,minimum,maximum,enum})；关系 ObjectRelation(id/name/target_object/cardinality/inverse_name)。枚举：data_type=string/integer/float/boolean/date/datetime；cardinality=one_to_one/one_to_many/many_to_one/many_to_many；modeling_type=manual/reverse/schema/hybrid。
2. **建模入口（5 类）**：手动表单、AI 自然语言(from-text)、文档逆向(from-doc，异步 job)、Excel 导入(from-excel)、模板实例化(templates)。生成结果默认 `draft`，**发布 `active` 后才写入 Jena 并被 MCP/图谱消费**。
3. **建模方法与反碎片**：实体=专有名词，概念=可复用术语；每源最多 5 实体 + 5 概念；禁止只写"待补充"的碎片页。
4. **坑**：属性 pattern（如 `^[A-Za-z0-9_\-]+$`）只认 ASCII，编码含中文会整批 0 条；产品线分组 enum 是**全角括号**（`服务器（SV、AI、边缘）`）；枚举值与源表完全一致才能命中。

## 实例批量导入（高频）
### 归化铁律（不可绕过）
LLM/字段映射输出**禁止直落库**，必须走：**preview → 候选(待审核) → 人工 approve(SHACL) → 落库(Neo4j/降级 JSONL)**。`data_gaps`/lookup 0 命中 → 由 Agent 转成"查不到 + 缺什么"并拒答。

### 推荐做法（避开最多坑）
1. **用 `POST /api/ingest/preview`（body 为 `IngestPreviewRequest`，`source.records` 为 JSON dict 列表）**，而不是 `/api/ingest/upload`（经 csv.DictReader 会把空字段读成空串 `""`，触发 SHACL 枚举/必填报 `Value Literal("") not in list`）。空字段直接**省略**。
   ```json
   {"ontology_id":"<oid>","object_type":"<obj>","source":{"kind":"field_map","records":[{"attr_x":"v","attr_y":1}]},"mapping":{"field_map":{"attr_x":"attr_x"}}}
   ```
2. **传参坑**：`object_type` 放 **body**（放 query 会被忽略并默认某对象）；`field_map` 放 body 且**必须非空**（identity map `{k:k}` 也可）。
3. **审批**：`POST /api/ingest/candidates/{candidate_id}/approve`（`get()` 返回 `(status, dict)` 元组，勿直接 `.json()`）。
4. **分页**：实例列表用 `page`/`pageSize`（别名 pageSize，上限 200），不是 `page_size/offset`（用错会固定返回 50 条）。
5. **大批量性能（Windows 常见坑）**：平台单对象存单个 JSONL，`insert` 曾为"整文件读改写 + os.replace"，`os.replace` 间歇抛 `WinError 5`（文件锁），且 approve 逐行全表扫描 O(n²)。修复后（追加写 + 稳定键索引）可分钟级万行。客户端规避：**小批次**（如 200~500/批）、approve 超时放宽（600s）、按库内已有 key 去重、断点续传（只记录**真正导入成功**的 key；脚本若无条件写 key 会在失败批次污染去重导致误判"全部已导入"）。参考 `scripts/import_instances.py`。
6. **稳定键**：组合键要唯一（如 `批次|区域|机型|条款|客户`，唯一性可先在源表验证，且长度 <64）。`attr_baseline_code` 等用 ASCII 国家码/分组码（如 `PD-CN-SVC-SRV`）。

## 实例修改
- **PUT 整体替换**：`PUT /api/ingest/instances/{id}` body 必须 `{"instance":{完整字段}}` —— 只传单字段会**清空其余属性**（曾当场踩坑）。字段级修改用 **PATCH**。
- **PATCH 不支持删键**（HF-10）：物理删除属性键需本体 v4 breaking 改动，先在平台排查再动。

## 能力与公式（L2）
- **执行**：`POST /api/capabilities/{cap_id}/execute {instance_id, inputs, dry_run}`。按**能力 id** 调（按 name 会 NOT_FOUND）；`dry_run=true` 不写回。`capability_call(capability=...)` 留空返回 active 能力清单。
- **inputs 语义**：是"覆盖 + 缺失回落实例存储值"，不是整体替换（D1 类需显式传 `attr_bom_set='NONE'` 否则沿用模板实例值）。
- **opl-expr 两条必记**：① `binds`（`a = this.x`）是**无条件预求值**，即便分支用不到也先算 → 键缺失即 `MISSING_INPUT_ATTR`，可选属性必须内联进 `if()` 参数；② 表达式**最后位置**避免多行嵌套 `if()`（易报"最后一个表达式之后不应再有内容"→ 先 bind 变量、final 只放单层选择）。
- **校验**：`POST /api/capabilities/{cap_id}/validate?draft_expression=<urlencoded>`（`/api/capabilities/validate` 不存在）。
- **lookup/ref**：`lookup()` 只读语义层（按维度键查基线实例）；`ref()` 只读上游能力（组引用链）。

## 问数分析（L4）
- **自然语言**：`POST /api/graph/{ontology_id}/nl-query?project_id=<pid>`（`nl_to_sparql()`，LLM + fallback）。LLM 需在设置里配好（llm_config.json + 进程 env 的 `LLM_API_KEY`）。
- **MCP 工具**：`ontology_query` / `instance_get` / `inference_trace` / `action_invoke` / `term_lookup` / `capability_call`（streamable-http + SSE 兼容）。
- **拒答/差距**：任一必需维度 lookup 0 命中 → `status=error` / `data_gaps` 非空 → 由 Agent 转成"查不到 + 缺什么"。**绝不编造数字**（"——"永不参与运算）。

## 逻辑跟踪（溯源）
- **溯源四要素**：能力（名称+版本）+ 输入（维度键）+ lookup 命中记录（带 `matched_record_id`，可回指）+ 计算值。`trace.refs` 给出上游能力链（如 F/E/K/N → O 求和）。
- **手算复核**：trace 的分项（如 59.0331/52.6376/27.3545/26.7080）与 round2 求和恰为 O，评委可手算验证。参考 `scripts/execute_capability.py`。

## 通用排错与性能
- **localhost→IPv6**：脚本 `BASE` 用 `http://127.0.0.1:8000`。
- **单文件 JSONL 扩容**：对象越大越慢（读改写 O(n²)）；大批量导入分批 + 断点。
- **HTTP 超时**：平台对大批量 preview/approve 可能 180s 超时；用 `-u` 无缓冲 + 日志重定向 + 分页加 `flush=True`。
- **浏览器自动化**：系统 Chrome `--headless=new --no-sandbox --disable-gpu --remote-debugging-port=9222 --user-data-dir=<tmp>`，再 `agent-browser connect 9222`；**勿用 npm shim**（bash 下路径被弄错成 D:/c/）；截图路径用 D 盘绝对路径。
- **PDF/打印**：Chrome `--headless=new --print-to-pdf` 在本机可能静默产不出文件（exit 0 无输出），改用 `--headless`（不带 new）+ 全新 profile；`>/dev/null` 会掩盖失败，需核对输出文件时间/大小。

## 资源
- `references/model_schema.md` —— 数据模型、枚举、稳定键、四层语义。
- `references/api_reference.md` —— 关键 REST 端点与请求/响应示例。
- `references/pitfalls.md` —— 按场景整理的坑与规避。
- `scripts/import_instances.py` —— 通用批量导入助手（preview+approve、去重、断点、分批）。
- `scripts/execute_capability.py` —— 执行能力 + 打印四要素溯源。
- `scripts/list_instances.py` —— 分页/按条件列出实例。
