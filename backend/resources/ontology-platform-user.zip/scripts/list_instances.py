# -*- coding: utf-8 -*-
"""分页列出平台实例（本体平台）。

用法示例：
  python list_instances.py --project 9619.. --ontology 509f.. --object-type obj_cost_detail --max-pages 3
  python list_instances.py --project 9619.. --ontology 509f.. --object-type obj_cost_detail --filter 'attr_batch=B2026Q3'
输出：total + items 汇总（csv 或 json）。
"""
import argparse, json, os, sys, requests

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--project", required=True)
    ap.add_argument("--ontology", required=True)
    ap.add_argument("--object-type", required=True)
    ap.add_argument("--filter", default="", help="attr=value 过滤（结果级，仅在本地过滤）")
    ap.add_argument("--page-size", type=int, default=200)
    ap.add_argument("--max-pages", type=int, default=0, help="0=全部")
    ap.add_argument("--out", default="", help="输出 json 文件；空则打印到 stdout")
    ap.add_argument("--token-file", default=None)
    a = ap.parse_args()

    token = open(a.token_file).read().strip() if a.token_file and os.path.exists(a.token_file) else ""
    if not token:
        print("缺少 token：--token-file 提供平台 Bearer token")
        sys.exit(1)

    rows = []; total = None; page = 1
    while True:
        resp = requests.get(f"{a.base}/api/ingest/instances?project_id={a.project}&ontology_id={a.ontology}"
                            f"&object_type={a.object_type}&pageSize={a.page_size}&page={page}",
                            headers={"Authorization": "Bearer " + token}, timeout=120).json()
        total = (resp.get("data") or {}).get("total")
        items = (resp.get("data") or {}).get("items") or []
        for it in items:
            rows.append(it.get("instance") or {})
        if not items: break
        page += 1
        if a.max_pages and page > a.max_pages: break

    # 结果级过滤
    if a.filter and "=" in a.filter:
        k, v = a.filter.split("=", 1)
        rows = [r for r in rows if str(r.get(k)) == v]
    print("total:", total, "pulled:", len(rows))
    if a.out:
        json.dump(rows, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print("saved ->", a.out)
    else:
        for r in rows[:20]:
            print(json.dumps(r, ensure_ascii=False))

if __name__ == "__main__":
    main()
