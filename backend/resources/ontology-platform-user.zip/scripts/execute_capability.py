# -*- coding: utf-8 -*-
"""执行公式能力并打印四要素溯源（本体平台）。

用法示例：
  python execute_capability.py --project 9619.. --cap-id cap_total_cost_q3 \
      --instance-id obj_maintenance_product_xxx --inputs '{"attr_model_code":"MDL-1003"}' \
      --dry-run True
返回：状态 + 值 + trace（inputs/lookups(matched_record_id)/refs）+ data_gaps
"""
import argparse, json, requests

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--project", required=True)
    ap.add_argument("--cap-id", required=True, help="能力 id（按 id，勿按 name）")
    ap.add_argument("--instance-id", required=True)
    ap.add_argument("--inputs", default="{}", help="JSON 字符串，覆盖 + 缺失回落实例值")
    ap.add_argument("--token-file", default=None)
    ap.add_argument("--dry-run", default="", help="传任意值表示 dry_run=true")
    a = ap.parse_args()

    token = open(a.token_file).read().strip() if a.token_file and __import__("os").path.exists(a.token_file) else ""
    if not token:
        print("缺少 token：--token-file 提供平台 Bearer token")
        raise SystemExit(1)

    body = {
        "instance_id": a.instance_id,
        "inputs": json.loads(a.inputs),
        "dry_run": bool(a.dry_run),
    }
    r = requests.post(f"{a.base}/api/capabilities/{a.cap_id}/execute?project_id={a.project}",
                      json=body, headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"},
                      timeout=300)
    try:
        d = r.json()
    except Exception:
        d = r.text
    print("status:", r.status_code)
    print(json.dumps(d, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
