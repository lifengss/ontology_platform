# -*- coding: utf-8 -*-
"""通用实例批量导入助手（本体平台）。

流程：preview -> 候选 -> approve（归化铁律）。空字段请先在 records 里省略。
通用参数：--base --project --ontology --object-type --records --token-file
可选：--stable-key <属性名>（去重，需库内已有 stable_key/stable_key_value 元数据）
      --batch 500 --timeout 600 --dry-run
用法示例：
  python import_instances.py --project 9619... --ontology 509f... \
      --object-type obj_cost_detail --records recs.json \
      --stable-key attr_detail_code --batch 500
"""
import argparse, json, os, sys, time
import requests

def login_token(base, user="admin", pwd_file=None):
    """优先读 token-file，否则用 admin 登录。"""
    # 由调用方传 token_file 更常见；此处仅兜底
    return None

def get(base, path, token, timeout=120):
    r = requests.get(base + path, headers={"Authorization": "Bearer " + token}, timeout=timeout)
    try: return r.status_code, r.json()
    except Exception: return r.status_code, r.text

def post(base, path, body, token, timeout=600):
    h = {"Authorization": "Bearer " + token, "Content-Type": "application/json"}
    r = requests.post(base + path, json=body, headers=h, timeout=timeout)
    try: return r.status_code, r.json()
    except Exception: return r.status_code, r.text

def existing_keys(base, project, ontology, objtype, stable_key, token):
    """分页拉取已存在 stable_key_value，用于去重。"""
    keys = set(); page = 1
    while True:
        st, d = get(base, f"/api/ingest/instances?project_id={project}&ontology_id={ontology}&object_type={objtype}&pageSize=200&page={page}", token)
        items = (d.get("data") or {}).get("items") or []
        if not items: break
        for it in items:
            k = (it.get("instance") or {}).get(stable_key)
            if k: keys.add(str(k))
        page += 1
        if page > 2000: break
    return keys

def import_batch(base, project, ontology, objtype, chunk, token, dry_run=False, timeout=600):
    # preview
    payload = {"ontology_id": ontology, "object_type": objtype,
               "source": {"kind": "field_map", "records": chunk},
               "mapping": {"field_map": {k: k for k in chunk[0]}}}
    st, d = post(base, f"/api/ingest/preview?project_id={project}", payload, token, timeout=timeout)
    if st not in (200, 201):
        return 0, {"error": d}
    cand = (d.get("data") or {}).get("candidate_id")
    violations = (d.get("data") or {}).get("violations") or []
    if violations:
        return 0, {"violations": violations[:3]}
    if dry_run:
        return len(chunk), {"preview_ok": True}
    # approve
    st2, d2 = post(base, f"/api/ingest/candidates/{cand}/approve?project_id={project}", {}, token, timeout=timeout)
    imported = (d2.get("data") or {}).get("imported", 0)
    return imported, d2

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8000")
    ap.add_argument("--project", required=True)
    ap.add_argument("--ontology", required=True)
    ap.add_argument("--object-type", required=True)
    ap.add_argument("--records", required=True, help="JSON 文件：list[dict]，空字段已省略")
    ap.add_argument("--token-file", default=None)
    ap.add_argument("--stable-key", default=None, help="去重用属性名")
    ap.add_argument("--resume-file", default=None, help="断点文件（每行一个已成功 key）")
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--timeout", type=int, default=600)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    token = ""
    if a.token_file and os.path.exists(a.token_file):
        token = open(a.token_file).read().strip()
    if not token:
        print("缺少 token：请在 --token-file 提供平台 Bearer token（POST /api/auth/login?mode=bearer 获取）")
        sys.exit(1)

    records = json.load(open(a.records, encoding="utf-8"))
    print("records:", len(records))

    # 去重
    done = set()
    if a.resume_file and os.path.exists(a.resume_file):
        done = set(l.strip() for l in open(a.resume_file, encoding="utf-8") if l.strip())
    if a.stable_key:
        done |= existing_keys(a.base, a.project, a.ontology, a.object_type, a.stable_key, token)
        print("已有 key（去重后）：", len(done))
    to_import = [r for r in records if not (a.stable_key and done and str(r.get(a.stable_key)) in done)]
    print("待导入：", len(to_import))

    t0 = time.time(); ok = 0; batches = 0
    kf = open(a.resume_file, "a", encoding="utf-8") if a.resume_file else None
    try:
        for i in range(0, len(to_import), a.batch):
            chunk = to_import[i:i+a.batch]
            imp, info = import_batch(a.base, a.project, a.ontology, a.object_type, chunk, token, a.dry_run, a.timeout)
            ok += imp; batches += 1
            if a.resume_file and kf and imp > 0:
                for r in chunk: kf.write(str(r.get(a.stable_key)) + "\n"); 
                kf.flush()
            print(f"[批{i//a.batch+1}] 共{len(chunk)} 导入{imp} 累计{ok}/{len(to_import)} 批次{batches} 耗时{int(time.time()-t0)}s", flush=True)
            time.sleep(0.3)
    finally:
        if kf: kf.close()
    print("完成，累计导入", ok)

if __name__ == "__main__":
    main()
